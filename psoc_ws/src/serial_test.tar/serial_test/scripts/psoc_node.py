#!/usr/bin/env python
import serial, rospy
from std_msgs.msg import String

def psoc_bridge():
    pub = rospy.Publisher('chatter', String, queue_size=10)
    psoc = serial.Serial('/dev/ttyUSB0', 19200)
    rospy.init_node('psoc', anonymous=True)
    r = rospy.Rate(10) #60hz
    rcv = ''
    while not rospy.is_shutdown():
        if psoc.inWaiting() > 0:
            rcv += psoc.read(8)
        str = rcv
        pub.publish(str)
        rcv = ''
        str = ''
        psoc.write(str)
        psoc.flush()
        r.sleep()

if __name__ == '__main__':
    try:
        psoc_bridge()
    except rospy.ROSInterruptException: pass
